/*
	Copyright@ Lalindu Lokuliyana
*/
#include<stdio.h>
#define NEW_MAX 10
// constant value "NEW_MAX" that can use anywhere
int main(){
	int i=0;
	do{
		printf("The value of i is =%d\n",i++);
	}while(i<=NEW_MAX);
}
